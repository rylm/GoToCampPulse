# GoToCampPulse
A website that tracks the number of people online in GoTo Camp
